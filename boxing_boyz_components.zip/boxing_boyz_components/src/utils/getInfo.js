import { ethers } from "ethers";
import { NFT, TOKEN, STAKING } from "./contracts";

export const getInfo = async(address) => {
    if(!window.ethereum) return;

    const provider = new ethers.providers.Web3Provider(window.ethereum);

    // instantiate contracts
    const nftContract = new ethers.Contract(NFT.address, NFT.abi, provider);
    const tokenContract = new ethers.Contract(TOKEN.address, TOKEN.abi, provider);
    const stakingContract = new ethers.Contract(STAKING.address, STAKING.abi, provider);

    // get information
    const tokenBalance = await tokenContract.balanceOf(address);

    let allNftIds = [];
    const nftBalance = await nftContract.balanceOf(address);
    for(let i = 0; i < nftBalance; i++) {
        const nft = await nftContract.tokenOfOwnerByIndex(address, i);
        allNftIds.push(nft);
    }


    const stakedNftIds = await stakingContract.allStakedTokensByOwner(address);
    let unstakedNfts = [];

    for(let i = 0; i < allNftIds.length; i++) {
        if(!stakedNftIds.includes()) {
            const uri = await nftContract.tokenURI(allNftIds[i]);
            unstakedNfts.push({ id: allNftIds[i].toString(), uri});
        }
    }

    // in this list, every staked nft has their own info like; stake time, current rewards etc.
    let stakedNfts = [];
    for(let i = 0; i < stakedNftIds.length; i++) {
        const [stakeStartTime, claimableRewards, nextRewards] = await stakingContract.getAllInfo(stakedNftIds[i]);
        const uri = await nftContract.tokenURI(stakedNftIds[i]);
        stakedNfts.push({
            id: stakedNftIds[i].toString(),
            stakeStartTime: stakeStartTime.toString(),
            claimableRewards: toNormal(claimableRewards),
            nextRewards: toNormal(nextRewards),
            uri,
        });
    }

    return {stakedNfts, unstakedNfts, tokenBalance};
}

const toNormal = (number) => {
    return ethers.utils.formatEther(number.toString());
}
